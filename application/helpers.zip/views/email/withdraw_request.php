<!DOCTYPE html>
<html>
<head>
	<title>Withdraw Request</title>
</head>
<body>
	Dear <?php echo $first_name ?>,

	Your withdraw request generated successfully

</body>
</html>