<!DOCTYPE html>
<html>
<head>
	<title>Sign up</title>
</head>
<body>
	Dear <?php echo $first_name ?>,

	Thank for you signup

</body>
</html>