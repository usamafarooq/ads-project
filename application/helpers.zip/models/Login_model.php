<?php 

class Login_model extends MY_Model
{
	
}