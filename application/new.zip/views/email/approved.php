<!DOCTYPE html>
<html>
<head>
	<title>Approved</title>
</head>
<body>
	Dear <?php echo $first_name ?>,

	Your account is approved

</body>
</html>