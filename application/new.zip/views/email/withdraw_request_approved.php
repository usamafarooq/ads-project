<!DOCTYPE html>
<html>
<head>
	<title>withdraw Approved</title>
</head>
<body>
	Dear <?php echo $first_name ?>,

	Your withdraw approved successfully

</body>
</html>