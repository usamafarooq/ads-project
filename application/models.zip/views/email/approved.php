<!DOCTYPE html>
<html>
<head>
	<title>Approved</title>
</head>
<body>
	Dear <?php echo $first_name ?>,

	Your Account at Click Pay Earn has been confirmed. Just visit our Website Log in to your Account and start earning.

	For any further queries and questions, simply contact us on WhatsApp at 0303-0900542.
	
	Regards,
	Team Click Pay Earn

</body>
</html>