<!DOCTYPE html>
<html>
<head>
	<title>Withdraw Request</title>
</head>
<body>
	Dear <?php echo $first_name ?>,

	Your withdrawal request has been received, we will go through your details, and your withdrawal will be confirmed within 24 hours.

	For any further queries and questions, simply contact us on WhatsApp at 0303-0900542.

	Regards,
	Team Click Pay Earn

</body>
</html>