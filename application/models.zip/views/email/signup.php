<!DOCTYPE html>
<html>
<head>
	<title>Sign up</title>
</head>
<body>
	Dear <?php echo $first_name ?>,

	Thank You for signing up at Click Pay Earn!

	Simply pay your package’s amount through “Jazz Cash” at 0303-0900542, and WhatsApp us the
	screenshot along with your Click Pay Earn ID, your account will be confirmed within 24 hours.

	<b>Account Details:</b>
	User Name: <?php echo $username ?>
	Package: <?php echo $package ?>
	Package amount: <?php echo $package_amount ?>

	For any further queries and questions, simply contact us on WhatsApp at 0303-0900542.

	Regards,
	Team Click Pay Earn
</body>
</html>