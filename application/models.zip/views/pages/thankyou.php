<style>
    .terms li {
        list-style: inherit;
        margin-left: 40px
    }
</style>

<div class="page-header" style="background: url('<?php echo base_url('front_assets/img/banner1.jpg') ?>');">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="breadcrumb-wrapper">
                    <h2 class="product-title">Terms</h2>
                    <ol class="breadcrumb">
                        <li><a href="<?php echo base_url() ?>">Home /</a></li>
                        <li class="current">Terms</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</div>

<section id="about" class="section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-12 col-xs-12">
                <div class="about-wrapper">
                    <h2 class="intro-title">THANK YOU</h2>

                    
                    <p>Thank you for signing up at Click Pay Earn. Please pay your Package amount through Meezan bank Acoount title CLICK PAY EARN  A/C # 9922 0103888288 or Jazz Cash/easy paisa at 0303-0900542 and send your ID and message screenshot through WhatsApp on same number. Your account will be approved within 24 hours of payment.</p><br>

                    

                </div>
            </div>
            <!-- <div class="col-md-6 col-lg-6 col-xs-12">
                <img class="img-fluid" src="<?php echo base_url('front_assets/img/about/about.png') ?>" alt="">
            </div> -->
        </div>
    </div>
</section>