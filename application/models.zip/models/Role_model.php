<?php 

class Role_model extends MY_Model
{
	
}