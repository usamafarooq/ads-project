<!DOCTYPE html>
<html>
<head>
	<title>withdraw Approved</title>
</head>
<body>
	Dear <?php echo $first_name ?>,<br><br>

	Your request of withdrawal has been approved, as per our company’s policy your withdrawal amount will be paid within 7 working days.<br><br>

	For any further queries and questions, simply contact us on WhatsApp at 0303-0900542.<br><br>

	Regards,<br>
	Team Click Pay Earn
</body>
</html>