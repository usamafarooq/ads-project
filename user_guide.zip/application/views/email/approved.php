<!DOCTYPE html>
<html>
<head>
	<title>Approved</title>
</head>
<body>
	Dear <?php echo $first_name ?>,<br><br>

	Your Account at Click Pay Earn has been confirmed. Just visit our Website Log in to your Account and start earning.<br><br>

	For any further queries and questions, simply contact us on WhatsApp at 0303-0900542.<br><br>
	
	Regards,<br>
	Team Click Pay Earn<br>

</body>
</html>