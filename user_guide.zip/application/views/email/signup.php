<!DOCTYPE html>
<html>
<head>
	<title>Sign up</title>
</head>
<body>
	Dear <?php echo $first_name ?>,<br><br>

	Thank You for signing up at Click Pay Earn!<br><br>

	Bank Name : Meezan <br>
	Bank Account Number : 99220103888288<br>
	Reference Number : 03030900542<br><br>

	After Payment Sent Successfully You Will Receive Confirmation Sms with TID And Amount Kindly Send Screen Shot To 0343-3173314 With Email Adress Your Will Be Approved In 10 Minutes<br><br>

	Payment Sending Instruction !<br>
	Step 1: Dial *786#  <br>
	Step 2: Select Send Money <br>
	Step 3 : Select Bank <br>
	Step 4 : Select Meezan <br>
	Step 6 : Enter 9922-0103888288<br>
	
	Step 7 :  Enter Amount <br>
	Step 8 : Enter 03433173314<br>
	
	Step 9 : Enter Easy Paisa/ Jazz Casa Pin<br><br>

	<!-- Simply pay your package’s amount through “Jazz Cash” at 0303-0900542, and WhatsApp us the screenshot along with your Click Pay Earn ID, your account will be confirmed within 24 hours.<br><br> -->

	<b>Account Details:</b><br>
	User Name: <?php echo $username ?><br>
	Package: <?php echo $package ?><br>
	Package amount: <?php echo $package_amount ?><br><br>

	For any further queries and questions, simply contact us on WhatsApp at 0303-0900542.<br>

	Regards,<br>
	Team Click Pay Earn<br>
</body>
</html>