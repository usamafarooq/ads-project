<!DOCTYPE html>
<html>
<head>
	<title>Withdraw Request</title>
</head>
<body>
	Dear <?php echo $first_name ?>,<br><br>

	Your withdrawal request has been received, we will go through your details, and your withdrawal will be confirmed within 24 hours. <br><br>

	For any further queries and questions, simply contact us on WhatsApp at 0303-0900542. <br><br>

	Regards,<br>
	Team Click Pay Earn<br>

</body>
</html>