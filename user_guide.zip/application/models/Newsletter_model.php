<?php
		    class Newsletter_model extends MY_Model{

		    	}