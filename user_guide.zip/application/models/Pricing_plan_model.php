<?php
		    class Pricing_plan_model extends MY_Model{

		    	}